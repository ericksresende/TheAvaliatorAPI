﻿namespace TheAvaliatorAPI.Model
{
    public class LoginRequest
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
