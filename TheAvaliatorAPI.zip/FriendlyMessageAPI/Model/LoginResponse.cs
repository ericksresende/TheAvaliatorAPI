﻿namespace TheAvaliatorAPI.Model
{
    public class LoginResponse
    {
        public string? Access_token { get; set; }
    }
}
